<div class="wrap">
    Admin main page.
    <?php
    ?>
</div>