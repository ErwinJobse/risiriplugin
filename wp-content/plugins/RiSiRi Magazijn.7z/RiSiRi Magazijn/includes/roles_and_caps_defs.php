<?php
// plugin specific defines used on array index
define( 'MEO_EVENT_ROLE_NAME' , 0); // ‘administrator’
define( 'MEO_EVENT_ROLE_ALIAS' , 1); // ‘Admin’
define( 'MEO_EVENT_ROLE_CAP_ARRAY' , 2); // array (‘ivs_meo_event_read’,
?>