=== Galleria ===
Contributors: Max den Ouden, Erwin Jobse, Jop de Meurichy, Owen Vermeulen
Tags: //todo add me
Requires at least: 4.8
Tested up to: 4.9
License: The MIT License
License URI: http://opensource.org/licenses/MIT


== Description ==

//todo: add me

== Installation ==

//todo: add me

== Frequently Asked Questions ==



== Screenshots ==

//todo: add me

== Changelog ==

//todo: add me
