
<?php include 'load.php'; ?>

<?php get_header(); ?>

<?php echo do_shortcode("[risiriTable]"); ?>

<?php get_footer(); ?>


